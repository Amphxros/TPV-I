// G13
// Amparo Rubio Bellon
// Jorge Zurdo Izquierdo
#include "Coche.h"

Coche::Coche(int mat, int precio, std::string model):
	mat_(mat), precio_(precio), model_(model)

{
}