// G13
// Amparo Rubio Bellon
// Jorge Zurdo Izquierdo
#include "Alquiler.h"

Alquiler::Alquiler(Coche* coche, Date date, int dias) :
	car_(coche), date_(date), days_(dias) { }
